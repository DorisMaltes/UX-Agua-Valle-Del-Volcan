import React, { useState, useEffect } from 'react';
import './servicios2.css';

const servicesData = [
  { id: 'home-delivery', title: 'Rellenado de Garrafones', description: "Aproveche nuestro servicio de rellenado rápido en sucursal. Agua purificada al instante, perfecta para su ritmo de vida activo." },
  { id: 'refilling', title: 'Entrega a Domicilio', description: "Reciba agua pura y fresca directamente en su hogar con nuestro conveniente servicio de entrega a domicilio. Siempre disponible, siempre pura."},
  { id: 'custom-bottles', title: 'Botellas Personalizadas', description: "Personalice su evento con botellas de agua únicas. Diseños exclusivos para hacer de cada ocasión algo especial y memorable." },
  { id: 'water-dispenser', title: 'Dispensadores Automáticos', description: 'Proporcione agua fresca y conveniente con nuestros modernos dispensadores automáticos.'},
  { id: 'bulk-supply', title: 'Servicio a Empresas', description: "Proporcione a su empresa agua de alta calidad con nuestro servicio a gran escala. Eficiencia y confiabilidad en cada entrega." }
];

const ServicesCircle = () => {
  const [centerService, setCenterService] = useState(servicesData[0].id);
  const [showDescription, setShowDescription] = useState(false);

  const handleServiceClick = (id) => {
    setCenterService(id);
    setShowDescription(true);
  };

  useEffect(() => {
    if (showDescription) {
      const timer = setTimeout(() => setShowDescription(false), 10000); // Hide description after 5 seconds
      return () => clearTimeout(timer); // Clear the timeout if the component unmounts or the state changes
    }
  }, [showDescription, centerService]);

  return (
    <section className="servicesCircle">
        <div className='tituloProceso' id='servicios2'>
            <h1>NUESTROS</h1>
            <h1>SERVICIOS</h1>
        </div>
      <p id='subtituloServicios'>Conoce los servicios que ofrecemos en Agua Purificada Valle del Volcán</p>
      <div id="circle-container">
        {servicesData.map((service, index) => (
          <Service
            key={service.id}
            id={service.id}
            title={service.title}
            description={service.description}
            isCenter={service.id === centerService}
            isDescriptionVisible={showDescription && service.id === centerService}
            angle={(index * 360) / servicesData.length}
            onClick={() => handleServiceClick(service.id)}
          />
        ))}
      </div>
    </section>
  );
};

const Service = ({ id, title, description, isCenter, isDescriptionVisible, angle, onClick }) => {
  const rotationStyle = {
    transform: `rotate(${angle}deg) translate(250px) rotate(-${angle}deg)`
  };

  return (
    <div
      className={`service ${isCenter ? 'center' : ''}`}
      style={isCenter ? {} : rotationStyle}
      onClick={onClick}
    >
      <h3>{title}</h3>
      {isDescriptionVisible && (
        <div className="description-overlay">
          <p>{description}</p>
        </div>
      )}
    </div>
  );
};

export default ServicesCircle;
