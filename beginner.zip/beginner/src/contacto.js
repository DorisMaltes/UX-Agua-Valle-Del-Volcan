import React from 'react';
import './Contacto.css'; // Ensure the CSS file is linked
import Spline from '@splinetool/react-spline';

function Contacto() {
  return (

    <div id="contacto" className="contact-section">

      <div className="card-container">
      <div className='titulo'>
      <h1>CONTACTO Y</h1>
      <h1>UBICACION</h1>
    </div>
        <div className="contact-info">
          <h2>Purificadora Valle del Volcán</h2>
          <p>📍 Cam. Real a San Andrés 1230, Sin Nombre de Col 4, 72810 San Andrés Cholula, Pue.</p>
          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3771.419628834263!2d-98.29018332494879!3d19.045279182153035!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85cfc79568c23d0f%3A0x5351b4dfd66713f3!2sPurificadora%20Valle%20del%20Volc%C3%A1n!5e0!3m2!1sen!2smx!4v1713583260758!5m2!1sen!2smx" 
            width="600" 
            height="200" 
            style={{border:"0"}} 
            allowfullscreen="" 
            loading="lazy" 
            referrerpolicy="no-referrer-when-downgrade">
          </iframe>
          <p>📞 221 530 4660</p>
        </div>
        <div className="contact-form-container">
          <h2>Contáctanos</h2>
          <p>Escribenos</p>
          <form className="contact-form">
            <input type="text" placeholder="Nombre" />
            <input type="email" placeholder="Email" />
            <input type="tel" placeholder="Teléfono" />
            <textarea placeholder="Comentarios"></textarea>
            <button type="submit">Enviar</button>
          </form>
        </div>
      </div>
      <div className="spline-container">
      <Spline scene="https://prod.spline.design/fDvGnopR8i87YeCX/scene.splinecode" />
      </div>

    </div>
  );
}

export default Contacto;