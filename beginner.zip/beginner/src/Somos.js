import React from 'react';
import './Somos.css'; 
import Vaso from './assets/vaso.png'
import '@coreui/coreui/dist/css/coreui.min.css'
import "bootstrap/dist/css/bootstrap.min.css";
import { CCardBody } from '@coreui/react'
import { CCardImage } from '@coreui/react'
import { CCard } from '@coreui/react'
import { CCardText } from '@coreui/react'
import { CCardTitle } from '@coreui/react'
import local from './assets/valledelVolcanLocation.jpeg'
import local2 from './assets/randomImg.jpg'
import local3 from './assets/random3.jpg'
import Flechita from './assets/flechita.png'

function Somos() {
    return (
      <div id="quienesSomos" className="section">
        
          <div className='tituloSomos'>
              <h1>SOBRE </h1>
              <h1> NOSOTROS</h1>
          </div>
       
        <p id='subtituloSomos'>Conoce Agua Purificada Valle del Volcán</p>

        <div className='contenedorSobreNosotros'>
        <img src={Vaso} className='rotatingVaso1'/>
        <img src={Flechita} className='flecha'/> 

             
                <CCard className='box1' style={{ width: '18rem' }}>
                    <CCardImage orientation="top" src={local2} />
                    <CCardBody>
                        <CCardTitle>Visión</CCardTitle>
                        <CCardText>
                        Aspiramos a ser el líder en calidad, servicio e hidratación en Puebla, destacados por nuestro agua purificada y la satisfacción al cliente. Planeamos expandir mediante alianzas con restaurantes y comunidades para fomentar el crecimiento y la excelencia en el servicio.
                        </CCardText>
                    </CCardBody>
                </CCard>

                <CCard className='box2' style={{ width: '18rem' }}>
                    <CCardImage orientation="top" src={local} />
                    <CCardBody>
                        <CCardTitle>Misión</CCardTitle>
                        <CCardText>
                        Proporcionar agua purificada de calidad óptima, caracterizada por su equilibrio perfecto de sales para la hidratación humana y la preparación de alimentos. Ofrecer un servicio puntual y oportuno.
                        </CCardText>
                    </CCardBody>
                </CCard>

                <CCard className='box3' style={{ width: '18rem' }}>
                    <CCardImage orientation="top" src={local3} />
                    <CCardBody>
                        <CCardTitle>Valores</CCardTitle>
                        <CCardText>
                            Integridad
                            <li>
                                <lu>Compromiso con la honestidad y la transparencia en todas las operaciones y relaciones.</lu> 
                            </li>
                            Calidad
                            <li>
                                <lu>Compromiso con la excelencia en cada producto o servicio ofrecido a los clientes.</lu> 
                            </li>
                        </CCardText>
                    </CCardBody>
                </CCard>

               
                

                
            

        </div>
    
      </div>
    );
  }
  
  export default Somos;
  