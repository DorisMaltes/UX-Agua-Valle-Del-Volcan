import React from 'react';
import './Proceso.css'; 
import Vaso from './assets/vaso.png'
import Step1 from './assets/step1.png'
import Step2 from './assets/step2.png'
import Step3 from './assets/step3.png'
import Step4 from './assets/step4.png'
import Step5 from './assets/step5.png'
import Step6 from './assets/step6.png'
import Step7 from './assets/step7.png'
import Step8 from './assets/step8.png'
import Step9 from './assets/step9.png'
import Step10 from './assets/step10.png'
import Step11 from './assets/step11.png'
import Step12 from './assets/step12.png'
import Flechita from './assets/flechita.png'

import Servicios from './Servicios'

function Proceso() {
  return (
    <div id="proceso" className="section" >
        
        <div className='tituloProceso'>
            <h1>PROCESO DE</h1>
            <h1>PURIFICACIÓN</h1>
            
        </div>
      
      <image src={Flechita} className='flecha'/> 

      <p id='subtituloProceso'>Conoce el proceso de purificación en Agua Purificada Valle del Volcán</p>

     
       

      <Servicios />

      
      
      {/*
      <div className="process-container">
      
        <div className="step">
          <p>1</p>
          <div>
            <img src={Step1} alt="Primer Paso del proceso"/>
            <p>Captación del Agua</p>
          </div>
        </div>

        <div className="step">
          <p>2</p>
          <div>
            <img src={Step2} alt="Segundo Paso del proceso"/>
            <p>Agua Cruda</p>
          </div>
        </div>

        <div className="step">
          <p>3</p>
          <div>
            <img src={Step3} alt="Tercer Paso del proceso"/>
            <p>Hidroneumático</p>
          </div>
        </div>

        <div className="step">
          <p>4</p>
          <div>
            <img src={Step4} alt="Cuarto Paso del proceso"/>
            <p>Filtros</p>
          </div>
        </div>

        <div className="step">
          <p>5</p>
          <div>
            <img src={Step5} alt="Quinto Paso del proceso"/>
            <p>Ablandador</p>
          </div>
        </div>

        <div className="step">
          <p>6</p>
          <div>
            <img src={Step6} alt="Sexto Paso del proceso"/>
            <p>Electrólisis</p>
          </div>
        </div>

        <div className="step">
          <p>7</p>
          <div>
            <img src={Step7} alt="Septimo Paso del proceso"/>
            <p>Agua Purificada</p>
          </div>
        </div>

        <div className="step">
          <p>8</p>
          <div>
            <img src={Step8} alt="Octavo Paso del proceso"/>
            <p>Ozonificación</p>
          </div>
        </div>

        <div className="step">
          <p>9</p>
          <div>
            <img src={Step9} alt="Noveno Paso del proceso"/>
            <p>Luz ultravioleta</p>
          </div>
        </div>


        <div className="step">
          <p>10</p>
          <div>
            <img src={Step10} alt="Decimo Paso del proceso"/>
            <p>Lavado</p>
          </div>
        </div>

        <div className="step">
          <p>11</p>
          <div>
            <img src={Step11} alt="Onceavo Paso del proceso"/>
            <p>Llenado</p>
          </div>
        </div>

        <div className="step">
          <p>12</p>
          <div>
            <img src={Step12} alt="Doceavo Paso del proceso"/>
            <p>Entrega</p>
          </div>
        </div>
        

        <div className="process-image">
         
          <img src={Vaso} alt="Proceso de Purificación" className="rotating" />
        </div>
        
      </div>
      */}
    </div>
  );
}

export default Proceso;
