import Vaso from './assets/vaso.png'
import React from 'react';
import './vasogiratorio.css'; 

function vasoGiratorio() {
    
    return (
        <img scr={Vaso} className="rotatingVaso"/>
      
    );
  }
  
  export default vasoGiratorio;