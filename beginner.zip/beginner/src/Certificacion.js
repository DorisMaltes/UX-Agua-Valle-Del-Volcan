import React from 'react';
import './Certification.css';
import moño from './assets/moño.png';
import certificadoImg from './assets/reconocimiento.jpg'; // Asegúrate de tener una imagen de certificado.
import Mes from './assets/certificacionMensual.png'
import Spline from '@splinetool/react-spline';

function Certificacion() {
  const mesesConRevision = 4;
  const meses = new Array('Enero', 'Febrero','Marzo', 'Abril','Mayo', 'Junio','Julio', 'Agosto','Septiembre', 'Octubre','Noviembre', 'Diciembre').fill(null);

  return (
    <div id="certificacion" className="section">
      <div className="tituloCertificacion">
        <h1>CERTIFICACIÓN</h1>
        <h1>DEL PROCESO DE AGUA</h1>
      </div>
      <p id="subtituloCertificacion">
        Conoce los certificados que respaldan nuestro proceso de purificación en Agua Purificada Valle del Volcán
      </p>

      <div className="container">
        <div className="image-box">
          <img src={certificadoImg} alt="Descripción" />
        </div>

        <div className="content-box">
          <p>Trataquim S.A de C.V nos respalda</p>
          <p>"Norma Oficial Mexicana NOM-201-SSA1-201"</p>
          <p>Esta Norma establece las características y especificaciones sanitarias que deben cumplir el agua y el hielo para consumo humano.</p>
          
        </div>

        <div className="image-box-moño">
        <Spline scene="https://prod.spline.design/6QYgm0SOmC53htq8/scene.splinecode" />
                </div>

      </div>

      <p id='certificacionMensual'>Nos gusta mejorar diariamente por lo tanto <br></br>este es nuestro Control de Calidad Bacterilógico mensual</p>

      <div className="circles-container">
          
            {meses.map((_, index) => (
              <div key={index} className={`circle ${index < mesesConRevision ? 'with-review' : ''}`}>
                
                {index < mesesConRevision && <img src={Mes} alt="Revisión Mensual" />}
              </div>
            ))}
      </div>


      {/*
      <secttion id='contieneCosasxd'>
          <div className="cards-container">
            
              <div className="card card2">
                <p>Texto placeholder para la Card 2. Aquí va el contenido sobre la participación y control de la norma oficial.</p>
              </div>
              
              <div className="card card1">
                <img src={certificadoImg} alt="Certificado" className="certificado-img"/>
                <img src={moño} alt="Moño" className="moño-img"/>
              </div>

          </div>
          
          <div className="circles-container">
            {meses.map((_, index) => (
              <div key={index} className={`circle ${index < mesesConRevision ? 'with-review' : ''}`}>
                {index < mesesConRevision && <img src={Mes} alt="Revisión Mensual" />}
              </div>
            ))}
          </div>
      </secttion>
       */}

    </div>
  );
}

export default Certificacion;
