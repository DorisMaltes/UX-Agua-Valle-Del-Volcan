import React from 'react';
import './Home.css'; 
import garrafon from './assets/garrafones.png';
import Wave from 'react-wavify'
import Spline from '@splinetool/react-spline';

function Home() {
  return (
    <div id="home" className="hero-section">
      <div className="hero-content">
        <p>AGUA PURIFICADA</p>
        <p>VALLE DEL VOLCÁN</p>
        <p>Productos de Agua Purificada y Agua Desionizada.</p>
      </div>
      
      <div>
        {/* Put the path to your image here */}
        <Spline scene="https://prod.spline.design/PGsyiPmtlI9QuRP1/scene.splinecode" />
              </div>
    </div>
    
  );
}


export default Home;
