import React from 'react';
import FancyCarousel from "react-fancy-circular-carousel";
import 'react-fancy-circular-carousel/FancyCarousel.css';
import './Servicios.css'


import image1 from './assets/step1.png';
import image2 from './assets/step2.png';
import image3 from './assets/step3.png';
import image4 from './assets/step4.png';
import image5 from './assets/step5.png';
import image6 from './assets/step6.png';
import image7 from './assets/step7.png';
import image8 from './assets/step8.png';
import image9 from './assets/step9.png';
import image10 from './assets/step10.png';
import image11 from './assets/step11.png';
import image12 from './assets/step12.png';
import { useState } from 'react';

function Servicios() {
    const [focusElement, setFocusElement] = useState(0);
    const images = [image1, image2, image3, image4,image5,image6,image7,image8,image9,image10,image11,image12];    
    const info = ['Paso 1', 'Paso 2', 'Paso 3','Paso 4','Paso 5','Paso 6','Paso 7', 'Paso 8', 'Paso 9','Paso 10','Paso 11','Paso 12'];
    const desc = ['Captación del agua', 'Agua cruda', 'Hidroneumático','Filtro de arena y carbón activado','Ablandador','Electrólisis','Agua Purificada', 'Ozonificación', 'Luz ultravioleta','Lavado','Llenado','Entrega'];

  return (
    <div id="servicios" className="">
      <div className="carousel">
        <div className='mainCarousel'>
          <FancyCarousel 
            images={images} 
            setFocusElement={setFocusElement}
            carouselRadius={200}
              peripheralImageRadius={50}
              centralImageRadius={50}
              focusElementStyling={{border: '2px solid #77A7E5'}}
              autoRotateTime={3}
              borderWidth={3}
              borderHexColor={'77A7E5'}
              navigationTextSize= {'3rem'}
              navigationButtonRadius= {'10px'}
              navigationButtonColor= {'FFFFFF'}
              navigationButtonBgColor = {'77A7E5'}

          />
              <div className="info-box-wrapper">
                <p> {info[focusElement]} </p>
                <p> {desc[focusElement]} </p>
              </div>
          </div>
      </div>
    </div>

  )
}

export default Servicios;