import React from 'react'

const descripcion1 = () => {
  return (
    <div>descripcion1</div>
  )
}

export default descripcion1