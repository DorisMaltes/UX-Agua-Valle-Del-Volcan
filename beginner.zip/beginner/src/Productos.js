import React from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import './Productos.css'
import garrafon from './assets/garrafonProducto.gif'
import botellaBoston from './assets/botellaBoston.png'
import botellaAnillada from './assets/botellaAnillada.png'

function TestimonialsCarousel() {
  // Configuración para el carrusel
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    nextArrow: <SampleNextArrow />,
    prevArrow: <SamplePrevArrow />,
  };

  // Personaliza las flechas del carrusel
  function SampleNextArrow(props) {
    const { className, style, onClick } = props;
    return (
      <div
        className={className}
        style={{ ...style, display: 'block', background:  'blue' }}
        onClick={onClick}
      />
    );
  }

  function SamplePrevArrow(props) {
    const { className, style, onClick } = props;
    return (
      <div
        className={className}
        style={{ ...style, display: 'block', background: 'blue' }}
        onClick={onClick}
      />
    );
  }

  return (
    <div className='productos'>
      <Slider {...settings}>
        
        <div className="testimonial1">
            <h3>Garrafón 20 Lts</h3>
            <p>Rellenado de Garrafones</p>
            <p>$15.00</p>
            <div className='testimonialImg'>
              <img src={garrafon}/>
            </div>
            
        </div>

        <div className="testimonial1">
            <h3>Personalización de Botellas</h3>
            <p>Botella Boston</p>
            <p>Botella de plástico Boston 1 lt, etiquetado con vinil eco mate o brillante con marca</p>
            <p>$13.50 c/u</p>
            <div className='testimonialImg1'>
              <img src={botellaBoston}/>
            </div>
        </div>

        <div className="testimonial1">
            <h3>Personalización de Botellas</h3>
            <p>Botella Boston</p>
            <p>Botella de plástico Boston 500 ml, etiquetado con vinil eco mate o brillante con marca</p>
            <p>$11.00 c/u</p>
            <div className='testimonialImg1'>
              <img src={botellaBoston}/>
            </div>
        </div>

        <div className="testimonial1">
            <h3>Personalización de Botellas</h3>
            <p>Botella Anillos</p>
            <p>Botella de plástico anillada 1 lt, etiquetado con marca</p>
            <p>$9.50 c/u</p>
            <div className='testimonialImg1'>
              <img src={botellaAnillada}/>
            </div>
        </div>

        <div className="testimonial1">
            <h3>Personalización de Botellas</h3>
            <p>Botella Anillos</p>
            <p>Botella de plástico anillada 500 ml, etiquetado con marca</p>
            <p>$7.50 c/u</p>
            <div className='testimonialImg1'>
              <img src={botellaAnillada}/>
            </div>
        </div>

        

        {/* aqui iran los servicios que ofre aga valle del volcán */}
      </Slider>
      
    </div>
    
  );
}

function Productos() {
  return (
    <div id="servicios" className="section">
      <div className='tituloProceso'>
            <h1>NUESTROS</h1>
            <h1>PRODUCTOS</h1>
        </div>
      <p className='paddingxd'>Descripción de los servicios que ofrecemos...</p>

      <div className='carruselLOL'>
        <TestimonialsCarousel />
      </div>
      
    </div>
  );
}

export default Productos;
