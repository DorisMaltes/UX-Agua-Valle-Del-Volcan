import React from 'react'

const Info1 = () => {
  return (
    <div>Info1</div>
  )
}

export default Info1